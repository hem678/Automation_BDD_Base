package step_definitions;

import static org.testng.AssertJUnit.assertEquals;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
 
import org.openqa.selenium.firefox.FirefoxDriver;

import com.amtrak.pages.AmtrakHomePage;
import com.amtrak.utilities.DriverFactory;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
 


public class VerifyAmtrakTitleSteps  extends DriverFactory       {
	//extends DriverFactory
	//WebDriver driver = new FirefoxDriver();
	Logger log = Logger.getLogger("devpinoyLogger");
     
	 
	//WebDriver driver;
	//AmtrakHomePage atkhomepage;
    
//    public VerifyAmtrakTitleSteps(driver) {
//		super(driver);
//		// TODO Auto-generated constructor stub
//	}

	@When("^I open amtrak website$")
    public void i_open_amtrak_website() throws Throwable {
         
    	//atkhomepage =new AmtrakHomePage(driver);
    	//atkhomepage.verifyLoginLink();
    	driver.get("https://www.amtrak.com/home");
    	new AmtrakHomePage(driver).verifyLoginLink();
    	log.debug("verifying LOGIN LINK LOG TEST");
        
    }

    @Then("^I validate title and URL$")
    public void i_print_title_and_URL() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	//String Currenttitile = driver.getCurrentUrl();
    	//System.out.println(Currenttitile);
    	new AmtrakHomePage(driver).verifyTitle();
      assertEquals("Train & Bus Tickets - National Railroad - USA & Canada | Amtrak",driver.getTitle());
      assertEquals("https://www.amtrak.com/home",driver.getCurrentUrl());
    }
    
}