package com.RC2.TestBase;

 

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Method;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import com.GE.automation.drivers.LocalDriver;
import com.GE.automation.drivers.MobileDriver;
import com.GE.automation.executionagent.BrowserAgent;
import com.GE.automation.executionagent.ExecutionAgent;
import com.GE.automation.executionagent.MobileAgent;
import com.GE.automation.property.reader.PropertyManager;
import com.GE.automation.utilities.Logg;
import com.GE.automation.utilities.ReadExcel;
import com.GE.automation.utilities.Utilities;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import io.appium.java_client.android.AndroidDriver;

import org.openqa.selenium.Platform;


public class TestBase {
	
	
	public static WebDriver driver=null;
	//private static final Properties frameworkProperty = PropertyManager
		//	.loadFrameworkPropertyFile("framework.properties");
	protected static final Logger log = Logg.createLogger();
	//protected final static Utilities util = new Utilities();
	//protected static String[][] strorage = null;
	//protected final static Properties applicationProperty = PropertyManager
		//	.loadApplicationPropertyFile("application.properties");
	//private AndroidDriver<?> mobileDriver;
	//private WebDriver webDriver;
	//private ITestContext context;
	//private static final String dateAndTimeFormat = "MM-dd-yyyy_hh.mm.ss";
//
//	@DataProvider(name = "ReadExcel")
//	public Object[][] readDataFromExcel(Method m) throws Exception {
//		log.info(Utilities.getCurrentThreadId() + "Data Provider: Read Excel");
//		log.info(Utilities.getCurrentThreadId() + "Data Provider: Running for Method: "
//				+ m.getName());
//		if ("enterAndValidateUniversityData".equals(m.getName())) {
//			strorage = ReadExcel.readTestData("Customer");
//			log.info(Utilities.getCurrentThreadId()
//					+ "Data Provider: Retrieved data from the Customer Sheet of Test Data Excel");
//		} else if ("".equals(m.getName())) {
//			strorage = ReadExcel.readTestData("Sheet2");
//		} else {
//			log.info(Utilities.getCurrentThreadId()
//					+ "NO MATCHING METHOD FOUND. PLEASE CHECK THE METHOD NAME IN THE DATA PROVIDER");
//		}
//		return strorage;
//	}
//
//	protected void logErrorMessage(Throwable ex) {
//		StringWriter stw = new StringWriter();
//		PrintWriter pw = new PrintWriter(stw);
//		ex.printStackTrace(pw);
//		log.error(stw.toString());
//	}
//
//	@BeforeMethod
//	protected void beforeMethod(ITestContext context) {
//		this.context = context;
//	}
//
//	protected WebDriver getMobileDriver(String mobileKey) {
//		ExecutionAgent agent = new MobileAgent(frameworkProperty.getProperty("network"),
//				frameworkProperty.getProperty("manufacturer"),
//				frameworkProperty.getProperty("deviceName"),
//				frameworkProperty.getProperty("deviceType"),
//				frameworkProperty.getProperty("deviceId"),
//				frameworkProperty.getProperty("platformVersion"),
//				frameworkProperty.getProperty("username"),
//				frameworkProperty.getProperty("password"),
//				frameworkProperty.getProperty("appPackage"));
//		mobileDriver = (AndroidDriver<?>) new MobileDriver().getDriver(agent);
//		context.setAttribute(mobileKey, mobileDriver);
//		return mobileDriver;
//	}
//
//	protected WebDriver getWebDriver(String webKey) {
//		ExecutionAgent agent = new BrowserAgent(frameworkProperty.getProperty("browserName"),
//				frameworkProperty.getProperty("browserVersion"), Platform.WINDOWS);
//		webDriver = new LocalDriver().getDriver(agent);
//		context.setAttribute(webKey, webDriver);
//		return ((WebDriver) context.getAttribute(webKey));
//	}
//
//	protected void closeBrowser(String driverKey) {
//		((WebDriver) context.getAttribute(driverKey)).quit();
//	}
//
//	protected void closeMobileApp() {
//		mobileDriver.quit();
//	}

	
	public void setup() throws Exception  { 
		
		
		Properties p=new Properties();
		
		FileInputStream fi=new FileInputStream("//Users//hemanthkumar//Documents//MyRepo//RC2//src//test//resources//properties//application.properties");
		
		 
		///Users/hemanthkumar/Documents/MyRepo/RC2/src/test/resources/properties/application.properties
		
		p.load(fi);
		//p.getProperty("browser");
		
		if(p.getProperty("browser").contains("fireFox"))
		{
			driver=new FirefoxDriver();
		}
		else if (p.getProperty("browser").contains("chrome"))
		{
			driver=new ChromeDriver();
		}
		
		driver.get(p.getProperty("applicationURL"));
	} 
	
	
	/*@AfterMethod
	protected File afterMethod(ITestResult result) throws IOException {
		WebDriver webdriver =((WebDriver) context.getAttribute("test"));
		if (result.isSuccess()) {
			return ((TakesScreenshot) webdriver).getScreenshotAs(OutputType.FILE);
		}
		if ("remote".equals(frameworkProperty.getProperty("executionType")))
			webdriver = new Augmenter().augment(webdriver);
		String dateAndTime = DateAndTime.getFormattedCurrentDateAndTime(dateAndTimeFormat);
		File screenshot = ((TakesScreenshot) webdriver).getScreenshotAs(OutputType.FILE);
		String screenShotName = Utilities.getCurrentThreadId().replace(":", "").replace("\t", "")
				+ dateAndTime + ".png";
		FileUtils.copyFile(screenshot, new File("./screenshots/" + screenShotName));
		return screenshot;
	}*/

	
	
	
	
	
	
	
	
	
//	
//	 // This Will Capture Screen Shot on Failure and Place Screen shot under screenshots Folder 
//	 @AfterMethod
//	 public void tearDown(ITestResult result) 
//	 
//	 { 
//		 if(ITestResult.FAILURE==result.getStatus())
//
//		 {
//			 Utilities.captureScreenShot(result.getName());
//		 }
//		 
//		 
//		 
//	 }
}