package com.RC2.RegressionSuite;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.GE.automation.Reusable.ReusableFunctions;
import com.GE.automation.pages.AddCarsKeyListPage;
import com.GE.automation.pages.VisualYardPage;
import com.RC2.TestBase.TestBase;

public class CreateViewFromKeyListTest extends TestBase {
	
	@BeforeClass 
	public void RC2Login() throws Exception { 
		
		setup();
		ReusableFunctions rf=new ReusableFunctions(driver);
		
		rf.verifyRoadMark();
		rf.verifyLogin();
	    rf.gotoEnv();
	    rf.gotoVisualYard();
		}
	
	
	
	@Test
	public void verifyCreateViewfromKeyList() throws Exception {
		
		VisualYardPage vypage=new VisualYardPage(driver);
		AddCarsKeyListPage klpage=new AddCarsKeyListPage(driver);
	
		vypage.gotoAddviewfromKeyList();
		klpage.addcars();
		klpage.clicksubmitBtn();
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}
	

}
