package com.RC2.RegressionSuite;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.GE.automation.Reusable.ReusableFunctions;
import com.GE.automation.pages.CreatePendingTrainPage;
import com.GE.automation.pages.SelectTrainMasterPage;
import com.GE.automation.pages.VisualYardPage;
import com.RC2.TestBase.TestBase;

public class CreatePendingTrainTest extends TestBase {

	
	
	@BeforeClass 
	public void RC2Login() throws Exception { 
		
		setup();
		ReusableFunctions rf=new ReusableFunctions(driver);
		
		rf.verifyRoadMark();
		rf.verifyLogin();
	    rf.gotoEnv();
	    rf.gotoVisualYard();
		}
	
	
	
	@Test
	public void verifyCreatePendingTrain() throws Exception { 
		
		
		VisualYardPage vypage=new VisualYardPage(driver);
		CreatePendingTrainPage cptpage=new CreatePendingTrainPage(driver);
		SelectTrainMasterPage stpage=new SelectTrainMasterPage(driver);
		
		vypage.selectcars();
		vypage.gotoCreatePendingTrainfromOptions();
		
		cptpage.clickRemoveCarsfromClipboard();
		cptpage.clickPendingTrainDropDown();
		
		stpage.selectTrainfromList();
		
		cptpage.clickSubmitButton();
		cptpage.clicksubmitonPendingTrainHeader();
		cptpage.clicksubmitonChangeTransaction();
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
