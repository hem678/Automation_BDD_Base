package com.RC2.RegressionSuite;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.GE.automation.Reusable.ReusableFunctions;
import com.GE.automation.pages.CreateWorkListPage;
import com.GE.automation.pages.SelectWorkListMasterPage;
import com.GE.automation.pages.VisualYardPage;
import com.RC2.TestBase.TestBase;

public class CreateWorkListTest extends TestBase {

	
	@BeforeClass 
	public void RC2Login() throws Exception   { 
		
		setup();
		ReusableFunctions rf=new ReusableFunctions(driver);
		
		rf.verifyRoadMark();
		rf.verifyLogin();
	    rf.gotoEnv();
	    rf.gotoVisualYard();
		}
	
	
	
	@Test
	public void verifyCreateWorkList() throws Exception { 
		
		
		VisualYardPage vypage=new VisualYardPage(driver);
		CreateWorkListPage cwlpage=new CreateWorkListPage(driver);
		SelectWorkListMasterPage swlpage=new SelectWorkListMasterPage(driver);
		
		vypage.selectcars();
		vypage.gotoCreateWorkList();
		
		cwlpage.clickRemoveCarsfromClipboard();
		cwlpage.clickWorkListIDDropDown();
		
		swlpage.selectWorkListfromList();
		
		cwlpage.clicksubmitbuttononCreateWLpopup();
		cwlpage.clicksubmitonWLHeader();
		cwlpage.clickBackButtonon();
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
