package com.RC2.RegressionSuite;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.GE.automation.Reusable.ReusableFunctions;
import com.GE.automation.pages.ListViewPage;
import com.GE.automation.pages.VisualYardPage;
import com.RC2.TestBase.TestBase;

public class CreateListViewFormat extends TestBase {
	
	
	@BeforeClass 
	public void RC2Login() throws Exception { 
		
		setup();
		ReusableFunctions rf=new ReusableFunctions(driver);
		
		rf.verifyRoadMark();
		rf.verifyLogin();
	    rf.gotoEnv();
	    rf.gotoVisualYard();
		}
	
	
	
	@Test
	public void verifyCreateListViewFormat() { 
		
		
		VisualYardPage vypage=new VisualYardPage(driver);
		ListViewPage lvpage=new ListViewPage(driver);
		
		vypage.clickListView();
		
		lvpage.clickListviewFormat();
		lvpage.clickaddButton();
		lvpage.changesequenceorder();
		lvpage.selectfields();
		lvpage.setListViewFormatName();
		lvpage.clickSubmitButton();
		lvpage.clickBackButton();
		
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	

}
