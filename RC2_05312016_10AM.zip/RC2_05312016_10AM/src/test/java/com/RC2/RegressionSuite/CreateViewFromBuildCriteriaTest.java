package com.RC2.RegressionSuite;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.GE.automation.Reusable.ReusableFunctions;
import com.GE.automation.pages.VisualYardBuildCriteriaPage;
import com.GE.automation.pages.VisualYardPage;
import com.RC2.TestBase.TestBase;

public class CreateViewFromBuildCriteriaTest extends TestBase {
	
	
	@BeforeClass 
	public void RC2Login() throws Exception { 
		
		setup();
		ReusableFunctions rf=new ReusableFunctions(driver);
		
		rf.verifyRoadMark();
		rf.verifyLogin();
	    rf.gotoEnv();
	    rf.gotoVisualYard();
		}
	
	
	
	@Test
	public void verifyCreateViewfromBuildCriteria() throws Exception {
		
		VisualYardPage vypage=new VisualYardPage(driver);
		
		VisualYardBuildCriteriaPage bcpage=new VisualYardBuildCriteriaPage(driver);
		
		
		vypage.gotoAddViewfromBuildCriteria();
		bcpage.setViewName();
		bcpage.clickStationDropDown();
		bcpage.gotoStation();
		bcpage.clikcSubmitButton();
		
		
	}
	
	
	
	
	
	

}
