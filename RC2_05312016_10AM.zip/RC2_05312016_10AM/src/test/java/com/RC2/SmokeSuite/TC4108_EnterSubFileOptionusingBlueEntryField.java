package com.RC2.SmokeSuite;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.GE.automation.Reusable.ReusableFunctions;
import com.GE.automation.pages.RailConnectMenuPage;
import com.GE.automation.pages.WayBillViewPage;
import com.RC2.TestBase.TestBase;

public class TC4108_EnterSubFileOptionusingBlueEntryField extends TestBase {
	
	
	@BeforeClass 
	public void RC2Login() throws Exception { 
		
		setup();
		ReusableFunctions rf=new ReusableFunctions(driver);
		
		rf.verifyRoadMark();
		rf.verifyLogin();
	    rf.gotoEnv();
	    
		}
	
	
	

	
	@Test
	public void validateBlueEntryFieldbySubFileOption() { 
		
		
		RailConnectMenuPage rcmenu=new RailConnectMenuPage(driver);
		WayBillViewPage wbvpage=new WayBillViewPage(driver);
		
		rcmenu.gotoWayBill();
		
		wbvpage.setSubFileOption();
		
		try{
	     	 Thread.sleep(5000);
	     	  
	     	Assert.assertTrue(driver.getPageSource().contains("Waybill Page1"));
	     	System.out.println("SubFile Option Accepted of WayBillView- Working as Expected");
	     	
		}catch(Exception ex){
	     		ex.printStackTrace();
	     	}
	}
		
		
		
		
	 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
