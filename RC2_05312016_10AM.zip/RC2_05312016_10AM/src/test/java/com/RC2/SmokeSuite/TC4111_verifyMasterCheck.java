package com.RC2.SmokeSuite;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.GE.automation.Reusable.ReusableFunctions;
import com.GE.automation.pages.RailConnectMenuPage;
import com.GE.automation.pages.WayBillViewPage;
import com.RC2.TestBase.TestBase;

public class TC4111_verifyMasterCheck extends TestBase {
	
	
	@BeforeClass 
	public void RC2Login() throws Exception { 
		
		setup();
		ReusableFunctions rf=new ReusableFunctions(driver);
		
		rf.verifyRoadMark();
		rf.verifyLogin();
	    rf.gotoEnv();
	    
		}
	
	
	

	
	@Test
	public void validateMasterCheckBox() { 
		
		RailConnectMenuPage rcmenu=new RailConnectMenuPage(driver);
		WayBillViewPage wbvpage=new WayBillViewPage(driver);
		
		
		rcmenu.gotoWayBill();
		
		wbvpage.clickMasterCheckBox();
		
		
	}
	
	
	
	
	

}
