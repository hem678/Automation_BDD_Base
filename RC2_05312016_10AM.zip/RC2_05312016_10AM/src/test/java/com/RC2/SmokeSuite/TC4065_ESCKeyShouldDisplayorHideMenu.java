package com.RC2.SmokeSuite;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.GE.automation.Reusable.ReusableFunctions;
import com.RC2.TestBase.TestBase;

public class TC4065_ESCKeyShouldDisplayorHideMenu extends TestBase {
	
	@BeforeClass 
	public void RC2Login() throws Exception { 
		
		setup();
		ReusableFunctions rf=new ReusableFunctions(driver);
		
		rf.verifyRoadMark();
		rf.verifyLogin();
	    rf.gotoEnv();
	    
		}
	
	
	

	
	@Test
	public void validateESCKey() { 
		
		
		
	}
	
	
	
	
	
	
	
	

}
