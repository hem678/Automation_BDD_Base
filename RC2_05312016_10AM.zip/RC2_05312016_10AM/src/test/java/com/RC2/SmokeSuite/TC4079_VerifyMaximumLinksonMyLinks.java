package com.RC2.SmokeSuite;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.GE.automation.Reusable.ReusableFunctions;
import com.GE.automation.pages.RailConnectMenuPage;
import com.RC2.TestBase.TestBase;

public class TC4079_VerifyMaximumLinksonMyLinks extends TestBase {

	//Test Description - A user will be able to add up to 19 TMS menu items to the My Links area.
	
	
	@BeforeClass 
	public void RC2Login() throws Exception { 
		
		setup();
		ReusableFunctions rf=new ReusableFunctions(driver);
		
		rf.verifyRoadMark();
		rf.verifyLogin();
	    rf.gotoEnv();
	    
		}
	
	
	

	
	@Test
	public void validateMaximumLinksunderMyLinks() throws Exception { 
		
		RailConnectMenuPage rcmenu=new RailConnectMenuPage(driver);
		
		rcmenu.verifyAddMainMenuLinkstoMyLinksMaximumTimes();
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
}
