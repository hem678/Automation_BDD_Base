package com.RC2.SmokeSuite;

import org.junit.AfterClass;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.GE.automation.Reusable.ReusableFunctions;
import com.GE.automation.pages.RailConnectMenuPage;
import com.RC2.TestBase.TestBase;

public class TC4071_OptionPathOperation extends TestBase   {
	
	
	
	@BeforeClass 
	public void RC2Login() throws Exception { 
		
		setup();
		ReusableFunctions rf=new ReusableFunctions(driver);
		
		rf.verifyRoadMark();
		rf.verifyLogin();
	    rf.gotoEnv();
	    
		}
	
	
	

	
	@Test
	public void validateOptionPathOperation() { 
		
		RailConnectMenuPage rcmenu=new RailConnectMenuPage(driver);
		
		rcmenu.gotoTMSMainMenu();
		rcmenu.gotoEDIMenu();
		
		try{
	     	 Thread.sleep(3000);
	     	  
	     	Assert.assertTrue(driver.getPageSource().contains("EDI"));
	     	System.out.println("Navigated to EDI Menu -  Option Path working as Expected");
	     	
		}catch(Exception ex){
	     		ex.printStackTrace();
		}
	}
	
 
	
	
	

}
