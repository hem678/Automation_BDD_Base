package com.RC2.SmokeSuite;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.GE.automation.Reusable.ReusableFunctions;
 
import com.GE.automation.listeners.ExtentReporterNG;
import com.GE.automation.pages.RailConnectMenuPage;
import com.RC2.TestBase.TestBase;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import mx4j.log.Logger;

public class TC4015_SignOff extends TestBase {
	
	//ExtentReports extent;
	//ExtentTest logger;
	
	
	@BeforeClass 
	public void RC2Login() throws Exception { 
		
		   
		
		setup();
		ReusableFunctions rf=new ReusableFunctions(driver);
		
		rf.verifyRoadMark();
		rf.verifyLogin();
	    rf.gotoEnv();
	    
		}
	
	
	

	
	@Test
	public void validateSignOff() { 
	 
		
	 //logger = extent.startTest("validateSignOff", "SignOffLogTest");
		
		
		RailConnectMenuPage rcmenu=new RailConnectMenuPage(driver);
		
		rcmenu.gotoLinks();
		rcmenu.gotoSignOff();
		
		try{
	     	 Thread.sleep(5000);
	     	  
	     	Assert.assertTrue(driver.getPageSource().contains("Welcome to RailConnect"));
	     	System.out.println("Signed Off Application - Working as Expected");
	     	//log.info("Application Loged Out - LOG Test"); // Debug for LOG Test 
	     	
	      
	     	
	     	//logger.log(LogStatus.PASS, "SignOff Working as Expected LOG Test");
	     	
		}catch(Exception ex){
	     		ex.printStackTrace();
		}
		
		
		
		
	}
	
	
	
	
	
	
//	 @AfterClass
//	 public void tear() { 
//		 
//		 extent.endTest(logger);
//		 extent.flush();
//		 extent.close();
//		 
//		 
//	 }
	
	
	
	
	
	
	

}
