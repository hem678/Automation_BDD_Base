package com.RC2.SmokeSuite;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.GE.automation.Reusable.ReusableFunctions;
import com.GE.automation.pages.RailConnectMenuPage;
import com.RC2.TestBase.TestBase;

public class TC4069_BackButtonOperation extends TestBase {
	
	@BeforeClass 
	public void RC2Login() throws Exception { 
		
		setup();
		ReusableFunctions rf=new ReusableFunctions(driver);
		
		rf.verifyRoadMark();
		rf.verifyLogin();
	    rf.gotoEnv();
	    
		}
	
	
	

	
	@Test
	public void validateBackButtonOperation() throws Exception { 
		
		
		RailConnectMenuPage rcmenu=new RailConnectMenuPage(driver);
		
		rcmenu.gotoTMSMainMenu();
		rcmenu.gotoRailOperations();
		rcmenu.goBacktoPreviousPage();
		
		try{
	     	 Thread.sleep(3000);
	     	  
	     	Assert.assertTrue(driver.getPageSource().contains("TMS Main Menu"));
	     	System.out.println("Navigated Back to TMS Main Menu -  Back Button Operation Working as Expected");
	     	
		}catch(Exception ex1){
	     		ex1.printStackTrace();
		}
	
	}
	
	
	
	
	
	
}
