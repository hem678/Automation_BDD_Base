package com.RC2.TestSuite;
//package com.GE.rc2.web.vh;
//
//import org.openqa.selenium.WebDriver;
//import org.testng.annotations.Test;
//
//import com.GE.automation.pages.SelectEnvPage;
//import com.GE.rc2.test.base.TestBase;
//
//public class gotoenvTest extends TestBase {
//	
//	 
//	
//	@Test
//	public void navigatetoEnv() {
//		
//    setup();
//	 
//	  
//	  
//	  try{
//   	 Thread.sleep(10000);
//   	}catch(Exception ex){
//   		ex.printStackTrace();
//   
//    
//	 
//   	}
// 
//}