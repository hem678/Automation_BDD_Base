package com.RC2.TestSuite;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.GE.automation.Reusable.ReusableFunctions;
import com.GE.automation.utilities.Constant;
import com.GE.automation.utilities.ExcelUtils;
import com.GE.automation.utilities.Utilities;
import com.RC2.TestBase.TestBase;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import java.io.FileInputStream;
import java.io.IOException;

//public class debug extends TestBase {
	
	
//	@Test
//	public void testdebug() throws Exception { 
		
//		setup();
//		ReusableFunctions rf=new ReusableFunctions(driver);
//		
//		rf.verifyRoadMark();
//		rf.verifyLogin();
//	    rf.gotoEnv();
//		}
	
	 
		 
		import java.text.DateFormat;
		import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import java.util.concurrent.TimeUnit;
		 
		 
		 
	public class debug extends TestBase {
 
		
		 
		
		
		
		
		 @Test
		public void verifyTitle() throws Exception { 
			 
		Logger logger=Logger.getLogger("verifyTitle");
			  
			  PropertyConfigurator.configure("log4j.properties");
			 setup();
			 
			 logger.info("Browser Started");
			 logger.info("Application launched");
			 
			
			 //Utilities.captureScreenShot("BrowserStated");	
		String Title=driver.getTitle();
		
		Assert.assertTrue(Title.contains(Title));
		 logger.info("Title Verified");
		 
		
		 
		
		}
		 
		  
		  
		 
	}

