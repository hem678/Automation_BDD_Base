package com.RC2.TestSuite;

import com.GE.automation.pages.rc2roadmarkpage;
import com.RC2.TestBase.TestBase;

import org.testng.Reporter;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Reporter;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;



import static org.apache.poi.ss.formula.CollaboratingWorkbooksEnvironment.setup;

/**
 * Created by hemanthkumar on 3/21/16.
 */



//extends - Acquire Other Class info to this class (here getting Global Config Properties info to this class)
public class rc2roadmarktest extends TestBase {


////	//*********Hard Coded Browser and Url *********************************
 	//WebDriver driver;
//	@BeforeTest
// 
//	public void setup()  {
//		
//		  driver=new FirefoxDriver();
//		  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		  driver.get("https://rc2qa.railconnect.com");
//
//
//	}
////	//*********************************************************************

    @Test
    public void VerifyRoadmark() throws Exception  {
        
    
        setup(); // To Call Browser Driver calling from TestBase 
        
        rc2roadmarkpage rc2rm = new rc2roadmarkpage(driver);

        rc2rm.setRoadmarkid();
        rc2rm.submit();
        //Reporter.log("Test Case #1 - Verify Road Mark PASSED");
        System.out.println("Test Case #1 - Verify Road Mark Working as Expected");
        //driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

    }



}