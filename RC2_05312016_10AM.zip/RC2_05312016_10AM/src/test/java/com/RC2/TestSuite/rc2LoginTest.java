package com.RC2.TestSuite;



import org.testng.annotations.Test;

import com.GE.automation.pages.RC2LoginPage;
import com.RC2.TestBase.TestBase;

public class rc2LoginTest extends TestBase {
	
	
	
	
	
	
	
	
	
	
	
	@Test
	public void verifyLogin() throws Exception {
		
		 setup();
		 RC2LoginPage rc2login=new RC2LoginPage(driver);
		 
		 rc2login.setUsername();
		 rc2login.setPassword();
		 rc2login.clickSubmit();
		}
	
	
	
	
	

}
