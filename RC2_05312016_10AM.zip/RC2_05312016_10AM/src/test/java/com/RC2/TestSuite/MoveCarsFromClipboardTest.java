package com.RC2.TestSuite;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.GE.automation.Reusable.ReusableFunctions;
import com.GE.automation.pages.MoveCarsPopUpPage;
import com.GE.automation.pages.VisualYardPage;
import com.RC2.TestBase.TestBase;

public class MoveCarsFromClipboardTest extends TestBase {
	
	
	
	
	
	@BeforeClass 
	public void RC2Login() throws Exception { 
		
		setup();
		ReusableFunctions rf=new ReusableFunctions(driver);
		
		rf.verifyRoadMark();
		rf.verifyLogin();
	    rf.gotoEnv();
	    rf.gotoVisualYard();
		}
	
	
	
	
	
	
	
	
	
	@Test
	public void verifyMoveCarsfromClipBoard() throws Exception { 
		//setup();
		
		VisualYardPage vypage=new VisualYardPage(driver);
		MoveCarsPopUpPage mcpage=new MoveCarsPopUpPage(driver);
		
		vypage.selectcars();
		vypage.gotoMoveCarsfromOptions();
		Assert.assertTrue(driver.getPageSource().contains("Move Cars"));
		
		mcpage.setMovetoTrack();
		mcpage.setTime("time");
		mcpage.checkRemoveCarsCheckBox();
		mcpage.clicksubmitbutton();
		
		
		
		
		
		
	}
	
	
	
	
	

}
