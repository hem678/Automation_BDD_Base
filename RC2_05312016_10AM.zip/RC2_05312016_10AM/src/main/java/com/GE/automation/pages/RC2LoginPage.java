package com.GE.automation.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.GE.automation.utilities.Constant;
import com.GE.automation.utilities.ExcelUtils;

public class RC2LoginPage {
	
	
	WebDriver driver;
	
	 //Locators / Objects 
	
	By usernameinput = By.id("MainContent_TopScreen__nlctl15");
	By passwordinput = By.id("MainContent_TopScreen__nlctl17");
	By submitbutton =  By.xpath("//a[contains(text(),'Submit')]");
	
	
	
	// Constructor
	public RC2LoginPage (WebDriver driver) {

    this.driver = driver;
    }

	//Method
	public void setUsername() throws Exception { 
		
		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.File_TestData,"Sheet1");
		
		String sUserName = ExcelUtils.getCellData(1, 1);
		 
		 
		driver.findElement(usernameinput).sendKeys(sUserName);
		
	}
	
	
	public void  setPassword() throws Exception { 
		
		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.File_TestData,"Sheet1");
		
		String sPassword = ExcelUtils.getCellData(1, 2);
		
		driver.findElement(passwordinput).sendKeys(sPassword);
		
	}
	
	
	public void clickSubmit() { 
		
		driver.findElement(submitbutton).click();
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	}

}
