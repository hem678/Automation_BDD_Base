package com.GE.automation.pages;

import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class VisualYardBuildCriteriaPage {
	
	
	WebDriver driver;
	
	//Locators / Objects 
	By forviewInput = By.id("MainContent_TopScreen__nlctl7");
	By stationdropdown = By.id("MainContent_TopScreen__nlctl11");
	By stationslistID = By.id("MainContent_TopScreen_ctl07");
	By submitbutton = By.xpath("//a[contains(text(),'Submit')]");
	By statusmessage = By.id("StatusBarPanel");
	
	
	// Constructor
			public VisualYardBuildCriteriaPage (WebDriver driver) {

		    this.driver = driver;
		    }

	//Method
	
	public void setViewName() throws Exception {
			Thread.sleep(5000);
			String randomNumbers = RandomStringUtils.randomNumeric(4);
			String viewdesc = "TEST " +randomNumbers;
			//System.out.println(viewdesc);
			driver.findElement(forviewInput).sendKeys(viewdesc);
			System.out.println("View Name Generated : " +viewdesc);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	
	
	public void clickStationDropDown() { 
		
		driver.findElement(stationdropdown).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		try{
	     	 Thread.sleep(5000);
	     	  
	     	Assert.assertTrue(driver.getPageSource().contains("Select Station"));
	     	System.out.println("Select Station Displayed - Working as Expected ");
	     	
		}catch(Exception ex){
	     		ex.printStackTrace();
	     	}
		
	}
	
	
	public void gotoStation() throws Exception { 
		
		Thread.sleep(5000);
		List<WebElement> stations = driver.findElements(stationslistID);
		
		Random r=new Random();
		int randomvalue = r.nextInt(stations.size());
		stations.get(randomvalue).click();
		 Thread.sleep(5000);
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		
		
	}
	
	
	public void clikcSubmitButton() {
		
		driver.findElement(submitbutton).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		try{
	     	 Thread.sleep(5000);
	     	 String StatusMessage = driver.findElement(statusmessage).getText();
	     	Assert.assertTrue(driver.getPageSource().contains(StatusMessage));
	     	System.out.println("Add View From Build Criteria Working as Expected   : " +StatusMessage);
	     	
		}catch(Exception ex){
	     		ex.printStackTrace();
	     	}
	}
	
	
	

}
