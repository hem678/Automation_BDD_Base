package com.GE.automation.pages;

import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class ListViewPage {
	WebDriver driver;
	
	 //Locators / Objects 
	
	By listviewformatbutton = By.xpath("//a[contains(text(),'List View Format')]");
	By Addbutton = By.id("MainContent_FunctionKeyPanel__nlctl19");
	By changeseqcancelbutton = By.xpath("//a[contains(text(),'Cancel')]");
	By fieldscheckbox = By.id("mainCheckBox");
	By formatnameinput = By.id("MainContent_TopScreen__nlctl803");
	By submitbutton = By.xpath("//a[contains(text(),'Submit')]");
	By sidedropdownmenu = By.id("sideDropDownMenu");
	By selectfromsidemenu = By.xpath("//a[contains(text(),'1=Select')]");
	By backbutton = By.xpath("//a[contains(text(),'back')]");
	
	// Constructor
			public ListViewPage (WebDriver driver) {

		    this.driver = driver;
		    }
	
	
	
	
	//Methods
	public void clickListviewFormat() { 
		
		driver.findElement(listviewformatbutton).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		try{
	     	 Thread.sleep(3000);
	     	 
	     	Assert.assertTrue(driver.getPageSource().contains("List View")); 
	     	 
	     	System.out.println("Select List View Format Displayed as Expected");
	     	}catch(Exception ex){
	     		ex.printStackTrace();
	     	}
		}
	
	
	public void clickaddButton() { 
		
		driver.findElement(Addbutton).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		}
	
	
	public void changesequenceorder() { 
		
		if (driver.getPageSource().contains("Change Sequence"))
			{
			driver.findElement(changeseqcancelbutton).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			}
		else 
		{
			System.out.println("File Format Layout Displayed");
		}
	}
	
	//Need to Debug Sometimes Select from Sidemenu is not Identifying 
	public void selectfields() { 
		
		
		driver.findElement(fieldscheckbox).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(selectfromsidemenu).click(); //Need to Debug Sometimes Select from Sidemenu is not Identifying 
		
		try{
	     	 Thread.sleep(6000);
	     	 
	     	Assert.assertTrue(driver.getPageSource().contains("SELECTED"));
	     	System.out.println("Fields Selected - As Expected");
	     	}catch(Exception ex){
	     		ex.printStackTrace();
	     	}
	}
	
	
	public void setListViewFormatName() { 
		
		String randomNumbers = RandomStringUtils.randomNumeric(4);
		String viewdesc = "TEST " +randomNumbers;
		 
		driver.findElement(formatnameinput).sendKeys(viewdesc);
		System.out.println("ListView Format Name Generated : " +viewdesc);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		
		
	}
	
	
	public void clickSubmitButton() { 
		
		driver.findElement(submitbutton).click();
		 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		 
		 try{
			 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	     	 
	     	 
	     	}catch(Exception ex){
	     		ex.printStackTrace();
	     	}
		}
	
	
	public void clickBackButton() { 
		
		driver.findElement(backbutton).click();
		 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		 try{
			  
			 Assert.assertTrue(driver.getPageSource().contains("List View"));
		     	System.out.println("List view Format Created - Working as Expected");
	     	 
	     	}catch(Exception ex){
	     		ex.printStackTrace();
	     	}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
