package com.GE.automation.page.base;

import org.openqa.selenium.WebDriver;

import com.GE.automation.actions.WebActions;
import com.GE.automation.exceptions.URLNavigationException;
import com.GE.automation.exceptions.WaitException;
//import com.GE.automation.pages.GoogleSearchPage;


public class WebPageBase extends PageBase {

	protected WebDriver driver;
	protected WebActions webActions;
	protected String webStrTempVar;

	public WebPageBase(WebDriver driver) throws WaitException {
		this.driver = driver;
		this.webActions = new WebActions(driver);
	}

	public WebPageBase navigateTo(String url) throws URLNavigationException, WaitException {
		webActions.navigateToURL(url);
		if (url.contains("google")) {
			return new WebPageBase(driver);
		} else {
			return null;
		}
	}
}
