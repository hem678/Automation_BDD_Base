package com.GE.automation.page.base;

import org.openqa.selenium.WebDriver;

import com.GE.automation.actions.MobileActions;
import com.GE.automation.exceptions.WaitException;

public class MobilePageBase extends PageBase {

	protected WebDriver driver;
	protected MobileActions mobileActions;

	public MobilePageBase(WebDriver driver) throws WaitException {
		this.driver = driver;
		this.mobileActions = new MobileActions(driver);
	}
}
