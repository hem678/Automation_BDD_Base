package com.GE.automation.exceptions;


public class URLNavigationException extends Exception {

	public URLNavigationException(String message, Throwable cause) {
		super(message, cause);
	}
}
