//package com.GE.automation.listeners;
//
//import java.io.IOException;
//
//import org.testng.ITestResult;
//import org.testng.TestListenerAdapter;
//
//import com.GE.automation.utilities.Utilities;
//
//public class CustomFailureListener extends TestListenerAdapter {
//	
//	//@Override
//	public void onTestfailure(ITestResult result) throws IOException { 
//		
//		
//		try {
//			Utilities.captureScreenShot("failtestSSTest");
//			
//		}catch (Exception e) {
//			
//			e.printStackTrace();
//		}
//		
//		
//		
//	}
//	
//	
//	
//	
//	
//	
//	
//
//}
