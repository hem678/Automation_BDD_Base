package com.GE.automation.pages;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.GE.automation.Reusable.ReusableFunctions;

public class MoveCarsPopUpPage {
	
	
	WebDriver driver;
	
	
	//Locators / Objects
	By movetoTrackinput = By.id("vyConfirmTrack");
	By timeInput = By.id("vyTimeConfirmId");
	By Removecarscheckbox = By.id("keepCarsInParkingLot");
	By submitbutton = By.xpath("//a[contains(text(),'Submit')]");
	By statusmessage = By.id("StatusBarPanel");
	
	
	
	
	
		// Constructor
			public MoveCarsPopUpPage (WebDriver driver) {

		    this.driver = driver;
		    }

			//Method
	
	     public void setMovetoTrack() { 
	    	 
	    	 driver.findElement(movetoTrackinput).clear();
	    	 driver.findElement(movetoTrackinput).sendKeys("MAIN1");
	    	 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    	 
	   }
	     
	     public void setTime(String time) { 
	    	 
	    	 SimpleDateFormat dateFormat = new SimpleDateFormat("HHmm");
			 Date date = new Date();
			 Calendar calendarAdd = Calendar.getInstance();
			 calendarAdd.add(Calendar.MINUTE,15);
			 String date1 = dateFormat.format(calendarAdd.getTime());
			 
			 driver.findElement(timeInput).sendKeys(date1);
			 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    	 }
	
	
	     public void checkRemoveCarsCheckBox() { 
		
		driver.findElement(Removecarscheckbox).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
	     }
	
	
	     public void clicksubmitbutton() { 
	    	 
	    	 driver.findElement(submitbutton).click();
	    	 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    	 try{
		     	 Thread.sleep(5000);
		     	 String StatusMessage = driver.findElement(statusmessage).getText();
		     	Assert.assertTrue(driver.getPageSource().contains(StatusMessage));
		     	System.out.println("Move Cars working as Expected with Status Message : " +StatusMessage);
		     	
			}catch(Exception ex){
		     		ex.printStackTrace();
		     	}
		     
	    	 
	    	 
	    	 
	    	 
	     }
	

}
