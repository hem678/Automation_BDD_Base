package com.GE.automation.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SelectEnvPage {
	
	
	WebDriver driver;
	
	 //Locators / Objects 
	By envpageinput = By.id("MainContent_TopScreen__nlctl5");
	By okbutton = By.xpath("//div[@id='MainContent_FunctionKeyPanel__nlctl1447']/a/span");
	
	
	// Constructor
		public SelectEnvPage (WebDriver driver) {

	    this.driver = driver;
	    }
	
	public void selectEnv() { 
		
		driver.findElement(envpageinput).sendKeys("1");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(okbutton).click();
		
//		try{
//       	 Thread.sleep(10000);
//       	}catch(Exception ex){
//       		ex.printStackTrace();
//       	}
//       
//		System.out.println("Selected QA Environment");
//	  
		
		
	}
	
	
	

}
