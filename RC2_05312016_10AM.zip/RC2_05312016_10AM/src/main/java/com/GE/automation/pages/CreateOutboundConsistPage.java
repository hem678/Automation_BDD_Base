package com.GE.automation.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class CreateOutboundConsistPage {

	WebDriver driver;
	
	 //Locators / Objects 
	By outboundCIDdropDown = By.id("vyOptionBtnArrows");
	By RemovecarsfromClipboardCheckbox = By.id("keepCarsInParkingLot");
	By submitbutton = By.xpath("//a[contains(text(),'Submit')]");
	By statusmessage = By.id("StatusBarPanel");
	By backbutton = By.xpath("//a[contains(text(),'Back')]");
	
	
	// Constructor
			public CreateOutboundConsistPage (WebDriver driver) {

		    this.driver = driver;
		    }

	//Method
			public void clickRemoveCarsfromClipboard() { 
				
				driver.findElement(RemovecarsfromClipboardCheckbox).click();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				
			}

			
			public void outboundConsistIDDropDown() { 
				
				driver.findElement(outboundCIDdropDown).click();
				driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
				try{
			     	 Thread.sleep(5000);
			     	 
			     	Assert.assertTrue(driver.getPageSource().contains("Select Train Master"));
			     	 
			     	System.out.println("Select Train Master Displayed as Expected");
			     }catch(Exception ex){
			     		ex.printStackTrace();
			     	}
				}


			public void clickSubmitButton() { 
				
				driver.findElement(submitbutton).click();
				driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
				try{
			     	 Thread.sleep(5000);
			     	 
			     	Assert.assertTrue(driver.getPageSource().contains("Outbound Consist Header"));
			     	 
			     	System.out.println("Outbound Consist Header Displayed as Expected");
			     }catch(Exception ex){
			     		ex.printStackTrace();
			     	}
			 }


			public void clickSubmitonOBConsistHeader() {

				driver.findElement(submitbutton).click();
				driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
				try{
			     	 Thread.sleep(8000);
			     	 
			     	Assert.assertTrue(driver.getPageSource().contains("Change Transaction?"));
			     	 
			     	System.out.println("Change Transaction Pop-up Displayed as Expected");
			     }catch(Exception ex){
			     		ex.printStackTrace();
			     	}
			
			
			}

			
			public void clickSubmitonChangeTransaction() { 
				
				driver.findElement(submitbutton).click();
				driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
				try{
			     	 Thread.sleep(8000);
			     	 
			     	String StatusMessage = driver.findElement(statusmessage).getText();
			     	System.out.println(StatusMessage);
			     }catch(Exception ex){
			     		ex.printStackTrace();
			     	}
			}
			
			
			public void clickBackButton() { 
				driver.findElement(backbutton).click();
				driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
				try{
			     	 Thread.sleep(8000);
			     	 
			     	String StatusMessage = driver.findElement(statusmessage).getText();
			     	System.out.println(StatusMessage);
			     }catch(Exception ex){
			     		ex.printStackTrace();
			     	}
				
				
				
				
			}













}
