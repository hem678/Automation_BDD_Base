package com.GE.automation.pages;

import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class MyReportsExtractsPage {

	
	WebDriver driver;
	
	 //Locators / Objects 
	
	 By reports = By.id("MainContent_TopScreen__nlgeb137");
			 //By.id("MainContent_TopScreen_ctl25");
			 //By.id("MainContent_TopScreen_ctl25");
	 //MainContent_TopScreen__nlgeb137
	
	 By reportscheckbox = By.id("ckb1");
	 By printreport 		= By.xpath("//a[contains(text(),'P=Print')]");
	 By openreport          = By.xpath("//div[@id='sideDropDownMenu']/div[3]/span");
	
	 //MainContent_TopScreen__nlctl10721:3:1
	
	
	
	
	// Constructor
			public MyReportsExtractsPage (WebDriver driver) {

		    this.driver = driver;
		    }
	
	
	
			
	//Methods
	
	public void verifyReportsareAvaialble() { 
		
		
		 if (driver.getPageSource().contains("waybill_print_overlay"))
		 {
		 System.out.println("Reports Available in the Page- Working as Expected ");
		 //driver.findElement(reportscheckbox).click();
		 }
		 else
		 { 
			 System.out.println("Reports Not Available Generate Reports and Verify Again");
		 }
		
	}
		

	
	public void openPDFReport() { 
		
		 if (driver.getPageSource().contains("waybill_print_overlay"))
		 {
		 System.out.println("Reports Available in the Page- Working as Expected ");
		 driver.findElement(reportscheckbox).click();
		 driver.findElement(openreport).click();
		 driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		 }
		 else
		 { 
			 System.out.println("Reports Not Available Generate Reports and Verify Again");
		 }
	}
	
	
	public void verifyPDFReport() { 
		
		
		String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
		String subWindowHandler = null;

		Set<String> handles = driver.getWindowHandles(); // get all window handles
		Iterator<String> iterator = handles.iterator();
		while (iterator.hasNext()){
		    subWindowHandler = iterator.next();
		}
		driver.switchTo().window(subWindowHandler); // switch to popup window
		                                            
		try{
	     	 Thread.sleep(7000);
	     	  
	     	Assert.assertTrue(driver.getPageSource().contains(".pdf"));
	     	System.out.println("PDF Report Verified - Working as Expected");
	     	
		}catch(Exception ex){
	     		ex.printStackTrace();
		}
		driver.switchTo().window(parentWindowHandler);  // switch back to parent window
		
		
		
	}
	
	
	
	
	
}
