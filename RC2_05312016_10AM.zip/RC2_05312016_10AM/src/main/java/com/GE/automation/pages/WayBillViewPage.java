package com.GE.automation.pages;

import java.awt.Desktop.Action;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

public class WayBillViewPage {
	
	
	
	WebDriver driver;
	
	 //Locators / Objects 
	
	By checkboxforList = By.id("ckb1");
	By mastercheckboxforlist = By.id("mainCheckBox");
	By recordinput = By.id("MainContent_TopScreen__nlgeb19961");
	//WebElement record = driver.findElement(recordinput);
	By OkButton = By.xpath("html/body/div[1]/div[2]/div[3]/table/tbody/tr/td/div/div/div[1]/a/span");
	By submitBtn =  By.xpath("//a[contains(text(),'Submit')]");
	By carslist = By.id("MainContent_TopScreen_ctl28");
	
	
	// Constructor
			public WayBillViewPage (WebDriver driver) {

		    this.driver = driver;
		    }
	
	
	
			
	//Methods
			
			public void clickCarCheckBox() { 
				
				
				driver.findElement(checkboxforList).click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			}
	
	
			public void clickMasterCheckBox() { 
				
				
				driver.findElement(mastercheckboxforlist).click();
				try{
			     	 Thread.sleep(2000);
			     	  
			     	Assert.assertTrue(driver.getPageSource().contains("B=Seed from Bill of Lading"));
			     	System.out.println("On Select MasterCheckBox - SubFile Menu Displayed as Expected");
			     	
				}catch(Exception ex){
			     		ex.printStackTrace();
			     	}
			}
	
			public void verifySubFileMenu() { 
				
				try{
			     	 Thread.sleep(2000);
			     	  
			     	Assert.assertTrue(driver.getPageSource().contains("B=Seed from Bill of Lading"));
			     	System.out.println("SubFile Menu Displayed as Expected");
			     	
				}catch(Exception ex){
			     		ex.printStackTrace();
			     	}
				
			} 
	
			
			public void clickRightClickonRecord() { 
				
				
					try {
						WebElement record = driver.findElement(recordinput);
						Actions action = new Actions(driver).contextClick(record);
						action.build().perform();

						Assert.assertTrue(driver.getPageSource().contains("B=Seed from Bill of Lading"));
				     	System.out.println("On Right CLick - SubFile Menu Displayed as Expected");
					} catch (StaleElementReferenceException e) {
						
								 e.getStackTrace();
					}
			}

			
			
			
			public void setSubFileOption() { 
				
				driver.findElement(recordinput).sendKeys("W");
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				driver.findElement(submitBtn).click();
				
				}
			
			
			
			
			
			
}
