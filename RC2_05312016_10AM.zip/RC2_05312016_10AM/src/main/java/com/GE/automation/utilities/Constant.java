package com.GE.automation.utilities;

public class Constant {
	
	
		  public static final String Path_TestData = "//Users//hemanthkumar//Documents//MyRepo//RC2//src//test//resources//testdata//";
		  
				  //"//Users//hemanthkumar//Documents//workspace//RC2//src//main//java//com//GE//automation//testData//";
	 
	      public static final String File_TestData = "TestData.xlsx";
	      
	 
	      //("//Users//hemanthkumar//Documents//workspace//RC2//src//test//resources//com//testdata//TestData.xlsx");

}
