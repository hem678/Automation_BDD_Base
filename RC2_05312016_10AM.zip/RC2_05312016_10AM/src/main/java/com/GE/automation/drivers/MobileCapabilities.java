package com.GE.automation.drivers;

import io.appium.java_client.remote.MobileCapabilityType;

import java.io.File;
import java.util.Properties;

import org.openqa.selenium.remote.DesiredCapabilities;

import com.GE.automation.executionagent.MobileAgent;
import com.GE.automation.property.reader.PropertyManager;


public class MobileCapabilities {

	private static DesiredCapabilities capabilities;
	private static final String APKPATH = "src/test/resources/com/apk";
	private static final Properties APPLICATIONPROPERTY = PropertyManager
			.loadApplicationPropertyFile("application.properties");

	private MobileCapabilities() {
	}

	public static DesiredCapabilities setAppiumNativeAppCapability(
			String deviceType, MobileAgent mobileAgent) {
		File appDir = new File(APKPATH);
		File app = new File(appDir,
				APPLICATIONPROPERTY.getProperty("mobileApk"));
		capabilities = new DesiredCapabilities();
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME,
				"Android");
		capabilities.setCapability("automationName", "appium");
		if ("emulator".equals(deviceType)) {
			capabilities.setCapability(MobileCapabilityType.DEVICE_NAME,
					mobileAgent.getDeviceName());
			capabilities.setCapability(MobileCapabilityType.UDID,
					mobileAgent.getDeviceId());
			capabilities.setCapability(MobileCapabilityType.APP,
					app.getAbsolutePath());
		} else if ("real".equals(deviceType)) {
			capabilities.setCapability(MobileCapabilityType.DEVICE_NAME,
					mobileAgent.getDeviceName());
			capabilities.setCapability(MobileCapabilityType.UDID,
					mobileAgent.getDeviceId());
			capabilities.setCapability(MobileCapabilityType.APP,
					app.getAbsolutePath());
		} else {
			capabilities.setCapability("user", mobileAgent.getUsername());
			capabilities.setCapability("password", mobileAgent.getPassword());
			capabilities.setCapability("platformVersion",
					mobileAgent.getPlatformVersion());
			capabilities.setCapability("network", mobileAgent.getNetwork());
			capabilities.setCapability("manufacturer",
					mobileAgent.getMaufacturer());
			capabilities.setCapability(MobileCapabilityType.DEVICE_NAME,
					mobileAgent.getDeviceName());
			capabilities.setCapability(MobileCapabilityType.APP,
					"PUBLIC:Samples/base.apk");
			capabilities.setCapability("appPackage",
					mobileAgent.getAppPackage());
		}
		return capabilities;
	}

	public static DesiredCapabilities setAppiumBrowserCapability() {
		capabilities = new DesiredCapabilities();
		capabilities.setCapability(MobileCapabilityType.BROWSER_NAME, "");
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME,
				"Android Emulator");
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME,
				"Android");
		return capabilities;
	}
}
