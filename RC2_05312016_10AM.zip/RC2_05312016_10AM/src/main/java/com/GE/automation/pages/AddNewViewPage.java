package com.GE.automation.pages;

import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class AddNewViewPage {

	WebDriver driver;
	
	 
	//Locators / Objects 
	By stationselectAll = By.xpath("//div[@id='ui-id-14']/input");
	By viewDescinput = By.id("nameOfNewView");
	By OKbtn = By.id("MainContent_FunctionKeyPanel__nlctl4890vyok");
	By statusmessage = By.id("StatusBarPanel");
	
	
	
	// Constructor
			public AddNewViewPage (WebDriver driver) {

		    this.driver = driver;
		    }

	//Method
		
			public void gotoStation() { 
				
				List<WebElement> listings = driver.findElements(By.id("listOfViewsID2"));
				
				Random r = new Random();
				
				int randomvalue = r.nextInt(listings.size());
				listings.get(randomvalue).click();
				
				
			}
	
	
			public void selectAllfromOptions() { 
				
				driver.findElement(stationselectAll).click();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				
 
				}
			
			
			public void setViewDesc() { 
				
				String randomNumbers = RandomStringUtils.randomNumeric(4);
				String viewdesc = "TEST " +randomNumbers;
				//System.out.println(viewdesc);
				driver.findElement(viewDescinput).sendKeys(viewdesc);
				System.out.println("View Description Generated : " +viewdesc);
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				
			}
	
	
			public void clickOKbutton() { 
				
				
				driver.findElement(OKbtn).click();
				
				try{
			     	 Thread.sleep(5000);
			     	 String StatusMessage = driver.findElement(statusmessage).getText();
			     	Assert.assertTrue(driver.getPageSource().contains(StatusMessage));
			     	System.out.println("Add View from Selected Tracks Working as Expected   : " +StatusMessage);
			     	
				}catch(Exception ex){
			     		ex.printStackTrace();
			     	}
			}
	
	
	
	
	
	
	
	
	
	
	
	
}
