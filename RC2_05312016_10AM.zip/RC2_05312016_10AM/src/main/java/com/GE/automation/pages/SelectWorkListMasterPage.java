package com.GE.automation.pages;

import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class SelectWorkListMasterPage {
	
	
	WebDriver driver;
	
	 //Locators / Objects 
	
	
	
	// Constructor
	public SelectWorkListMasterPage (WebDriver driver) {

    this.driver = driver;
    }

	//Method
	
	public void selectWorkListfromList() { 
		
		List<WebElement> trains = driver.findElements(By.id("MainContent_TopScreen_ctl14"));
		
		Random r = new Random();
		
		int randomvalue = r.nextInt(trains.size());
		trains.get(randomvalue).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		
		try{
	     	 Thread.sleep(5000);
	     	 
	     	 
	     	 
	     	 
	     }catch(Exception ex){
	     		ex.printStackTrace();
	     	}
		}
	
	 
	
	
	
	
 

}
