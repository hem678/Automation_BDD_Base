package com.GE.automation.pages;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;

import com.GE.automation.listeners.ExtentReporterNG;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.relevantcodes.extentreports.common.ExtentManager;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class RailConnectMenuPage {

	
	
	 

	//private static final WebElement Webelement = null;

	private static final WebElement WebElement = null;

	WebDriver driver;
//	ExtentReports report;
//	ExtentTest logger;
	
	 //Locators / Objects 
	
	By LinksDropDown = By.id("linksId");
	By visualyardLink = By.xpath("//a[contains(text(),'Visual Yard')]");
	By fastpathinput = By.id("dmFastPathInput");
	By OKbtn         = By.xpath("//a[contains(text(),'Submit')]");
	//By OKbtn = By.id("MainContent_FunctionKeyPanel__nlctl4890vyok"); dmSubmitBtn
	By OKbutton = By.xpath("//div[@id='MainContent_FunctionKeyPanel__nlctl4890vylv4']/a/span");
	By Backbutton = By.xpath("//a[contains(text(),'Back')]");
	By changeroadinput = By.id("ddcrid");
	By changeroadinputGobtn = By.xpath("//ul[@id='roadListDD']/li/table/tbody/tr/td[2]/a/img");
	By Optioninput = By.id("dmOptionInput");
	By descInput  = By.id("dmDescInput");
	By submitBtn =  By.xpath("//a[contains(text(),'Submit')]");

	//Links - Locators 
	By MenuNotepadLink 		= By.xpath("//a[contains(text(),'Menu Notepad')]");
	By MenuEscKeyLink  		= By.xpath("//a[contains(text(),'Menu (Esc Key)')]");
	By MyReportsLink        = By.xpath("//a[contains(text(),'My Reports')]");
	By VisualTrainsLinks 	= By.xpath("//a[contains(text(),'Visual Trains')]");
	By ShowpageIDlInk 	    = By.xpath("//a[contains(text(),'Show Page ID')]");
	By hidepageIDlink		= By.xpath("//a[contains(text(),'Hide Page ID')]");
	By LanguageLink 		= By.xpath("//a[contains(text(),'Language')]");
	By MenuStyleLink		= By.xpath("//a[contains(text(),'Menu Style')]");
	By hideDynamicMenulink  = By.xpath("//a[contains(text(),'Hide Dynamic Menu')]");
	By displayDynamicMenulink  = By.xpath("//a[contains(text(),'Display Dynamic Menu')]");
	By HelpLink  			= By.xpath("//a[contains(text(),'Help')]");
	By Helpdocslink         = By.partialLinkText("Release Highlights");
	By ChangeRoadLink		= By.xpath("//a[contains(text(),'Change Road')]");
	By Signofflink 			= By.xpath("//a[contains(text(),'Sign-Off')]");
	By spanishlanguagelink  = By.xpath("//a[contains(text(),'Spanish')]");
	By pageidstatusmessage 		= By.id("MainContent_TopScreen__nlctl994");
	
	
	//Main Menu Locators
	By TMSMainMenuLink = By.id("dmLinkTMS Main Menu");

	// Constructor
		public RailConnectMenuPage (WebDriver driver) {

	    this.driver = driver;
	    }
		
	public void clickBackButton() { 
		
		driver.findElement(Backbutton).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
	}	
	
	public void gotoLinks() { 
		
		driver.findElement(LinksDropDown).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	public void gotoVisualYardLink() { 
		
		
		driver.findElement(LinksDropDown).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(visualyardLink).click();
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		
	}

	
	public void gotoMyReports() { 
		
		
		driver.findElement(MyReportsLink).click();
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		
	}

	public void gotoWayBill() {
		
		driver.findElement(fastpathinput).sendKeys("WBA");
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		driver.findElement(OKbtn).click();
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		
		try{
	     	 Thread.sleep(2000);
	     	  
	     	Assert.assertTrue(driver.getPageSource().contains("Waybill View/Select"));
	     	System.out.println("WayBill View/Select Displayed as Expected");
	     	
		}catch(Exception ex){
	     		ex.printStackTrace();
	     	}
	}

	
	public void gotoMenuNotepad() { 
		
		
		driver.findElement(LinksDropDown).click();
		driver.findElement(MenuNotepadLink).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		try{
	     	 Thread.sleep(2000);
	     	  
	     	Assert.assertTrue(driver.getPageSource().contains("Active Waybills"));
	     	System.out.println("Menu Notepad History Verified - Working as Expected");
	     	
		}catch(Exception ex){
	     		ex.printStackTrace();
	  }
	}
	
	
	public void gotoVisualTrainsLink() { 
		
		//driver.findElement(LinksDropDown).click();
		driver.findElement(VisualTrainsLinks).click();
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		try{
	     	 Thread.sleep(2000);
	     	  
	     	Assert.assertTrue(driver.getPageSource().contains("Visual Trains"));
	     	System.out.println("Visual Trains Launched - as Expected");
	     	
		}catch(Exception ex){
	     		ex.printStackTrace();
	  }
		
	}
	
	
	public void gotoShowPageID() { 
		//MainContent_TopScreen__nlctl994
		//driver.findElement(LinksDropDown).click();
		driver.findElement(ShowpageIDlInk).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		try{
	     	 Thread.sleep(2000);
	     	 String StatusMessage = driver.findElement(pageidstatusmessage).getText();
	     	 
	     	System.out.println("Displayed Page ID   : " +StatusMessage);
	     	
		}catch(Exception ex){
	     		ex.printStackTrace();
	     	}
		driver.findElement(LinksDropDown).click();
		driver.findElement(hidepageIDlink).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		}
	
	
	public void gotoLanguage() {
		
		driver.findElement(LinksDropDown).click();
		driver.findElement(LanguageLink).click();
		driver.findElement(spanishlanguagelink).click();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		try{
	     	 Thread.sleep(2000);
	     	  
	     	Assert.assertTrue(driver.getPageSource().contains("Mensajes"));
	     	System.out.println("Spanish Version Displayed - as Expected");
	     	
		}catch(Exception ex){
	     		ex.printStackTrace();
	  }
		
		
	}
	
	
	public void gotoMenuStyle() { 
		
		driver.findElement(LinksDropDown).click();
		driver.findElement(MenuStyleLink).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	public void gotoHideDynamicMenu() { 
		
		driver.findElement(hideDynamicMenulink).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		try{
	     	 Thread.sleep(2000);
	     	  
	     	Assert.assertFalse(driver.getPageSource().contains("Menu Notepad"));
	     	System.out.println("Dynamic Menu Hidden - as Expected");
	     	
		}catch(Exception ex){
	     		ex.printStackTrace();
	  }
	}
	
	
	public void gotoDisplayDynamicMenu() { 
		
		driver.findElement(LinksDropDown).click();
		driver.findElement(MenuStyleLink).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(displayDynamicMenulink).click();
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	}
	
	
	public void gotoHelp() { 
		//driver.findElement(LinksDropDown).click();
		driver.findElement(HelpLink).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(Helpdocslink).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		}
	
	public void verifyHelpDocs() { 
		
		String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
		String subWindowHandler = null;

		Set<String> handles = driver.getWindowHandles(); // get all window handles
		Iterator<String> iterator = handles.iterator();
		while (iterator.hasNext()){
		    subWindowHandler = iterator.next();
		}
		driver.switchTo().window(subWindowHandler); // switch to popup window
		                                            
		try{
	     	 Thread.sleep(7000);
	     	  
	     	Assert.assertTrue(driver.getPageSource().contains("Release"));
	     	System.out.println("Help Documents Verified - Working as Expected");
	     	
		}catch(Exception ex){
	     		ex.printStackTrace();
		}
		driver.switchTo().window(parentWindowHandler);  // switch back to parent window
		
	}
	 
	
	
	public void gotoChangeRoad() { 
		
		//driver.findElement(LinksDropDown).click();
		driver.findElement(ChangeRoadLink).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}
	
	
	public void setChangeRoadInput() { 
		
		driver.findElement(changeroadinput).sendKeys("EQ56"); // Need to troubleshoot for Datadriven
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(changeroadinputGobtn).click();
		try{
	     	 Thread.sleep(8000);
	     	  
	     	Assert.assertTrue(driver.getPageSource().contains("EQ56"));
	     	System.out.println("Changed RoadName to EQ56 - Working as Expected");
	     	
		}catch(Exception ex){
	     		ex.printStackTrace();
		}
		
	}
	
	public void gotoSignOff() { 
		
		//report.startTest("gotoSignOff", "go to Sign Off");
		driver.findElement(LinksDropDown).click();
		//logger.log(LogStatus.INFO, "Clicked on Links - Log Test");
		driver.findElement(Signofflink).click();
		//logger.log(LogStatus.INFO, "Clicked on SignOff - Log Test");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
//		try{
//	     	 Thread.sleep(5000);
//	     	  
//	     	Assert.assertFalse(driver.getPageSource().contains("Welcome to RailConnect"));
//	     	System.out.println("Signed Off Application - Working as Expected");
//	     	
//		}catch(Exception ex){
//	     		ex.printStackTrace();
//		}
		}
	
	public void verifyOKandEnterKeyOperation() { 
		
		driver.findElement(Optioninput).sendKeys("1");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(OKbutton).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
	}
	
	
	
	public void gotoTMSMainMenu() { 
		
		driver.findElement(Optioninput).sendKeys("1");
		driver.findElement(OKbtn).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		try{
    	 Thread.sleep(2000);
    	  
    	Assert.assertTrue(driver.getPageSource().contains("TMS Main Menu"));
    	System.out.println("Navigated to TMS Main Menu -  as Expected");
    	
		}catch(Exception ex){
    		ex.printStackTrace();
		}
	}	
	
	public void gotoRailOperations() {
		
		driver.findElement(Optioninput).sendKeys("1");
		driver.findElement(OKbtn).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		try{
	    	 Thread.sleep(2000);
	    	  
	    	Assert.assertTrue(driver.getPageSource().contains("Rail Operations"));
	    	System.out.println("Navigated to Rail Operations -  as Expected");
	    	
			}catch(Exception ex){
	    		ex.printStackTrace();
			}
		}
	
	
	public void goBacktoPreviousPage() throws Exception { 
		Thread.sleep(3000);
		driver.findElement(Backbutton).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
	}
	 
	
	
	public void gotoEDIMenu() { 
		
		driver.findElement(Optioninput).sendKeys("35");
		driver.findElement(OKbtn).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		
	}
	
	
	
	 public void verifyDescriptionOperation() { 
		 
		 driver.findElement(descInput).sendKeys("Active Waybills (Online Cars)");
		 driver.findElement(submitBtn).click();
		 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		 
	 }
	
	
	 
	 
	 public void verifyESCKey() { 
		 
		 	Actions action = new Actions(driver);
		    action.sendKeys(Keys.ESCAPE).build().perform();
		    try{
		    	 Thread.sleep(5000);
		    	  
		    	Assert.assertTrue(driver.getPageSource().contains("Railconnect Menu"));
		    	System.out.println("RailConnect Menu Displayed on Tap ESC Key  -  as Expected");
		    	
				}catch(Exception ex){
		    		ex.printStackTrace();
				}
		    
		    action.sendKeys(Keys.ESCAPE).build().perform();
		    try{
		     	 Thread.sleep(2000);
		     	  
		     	Assert.assertTrue(driver.getPageSource().contains("Visual Trains"));
		     	System.out.println("Navigated Back to Visual Trains on Tap ESC again - ESC Key Operation working as Expected");
		     	
			}catch(Exception ex){
		     		ex.printStackTrace();
		  }
		 
		 
	 }
	 
	 
	 
	 public void verifySubFileOptionsMenu()  { 
		 
		 
		 
		 
		 
	 }
	 
	 
	public void verifyAddMainMenuLinkstoMyLinksMaximumTimes() throws Exception { 
		
		for (int i = 0; i < 20; i++){
		WebElement elementOpen = driver.findElement(TMSMainMenuLink);
		Actions oAction = new Actions(driver);
		oAction.moveToElement(elementOpen);
		oAction.contextClick(elementOpen).build().perform();  /* this will perform right click */
		///WebElement elementOpen = driver.findElement(TMSMainMenuLink);
		
		//elementOpen.findElement(By.linkText("Add to My Links")).click();
		
		//for (int i = 0; i < 20; i++){
			 //click the button
			
			//elementOpen.findElement(By.xpath("//a[contains(text(),'Add to My Links')]")).click(); 
			WebDriverWait wait = new WebDriverWait(driver, 30);

			WebElement title = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'Add to My Links')]")));
			title.click();
			
	
		 
			
			
			
//			for(int j=0; j<4;i++) 
//				try 
//			{ 
//					elementOpen.findElement(By.xpath("//a[contains(text(),'Add to My Links')]")).
//					clear(); break; 
//			} 
//			catch(StaleElementReferenceException e) 
//			{ e.toString(); 
//			
//			System.out.println("Trying to recover from a stale element :" + e.getMessage()); 
//			
//			}  
			
			//elementOpen.findElement(By.xpath("//a[contains(text(),'Add to My Links')]")).click();
			 
			 //wait 2 seconds
			  Thread.sleep(5000);
			  //check that data is being generated correctly
			   
			}
		
		 
		
		
		
		
	}
	
}
