package com.GE.automation.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class CreatePendingTrainPage {
	
	
	WebDriver driver;
	
	 //Locators / Objects 
	
	By PendingTraindropdownbutton = By.id("vyOptionBtnArrows");
	By RemovecarsfromClipboardCheckbox = By.id("keepCarsInParkingLot");
	By submitbutton = By.xpath("//a[contains(text(),'Submit')]");
	By statusmessage = By.id("StatusBarPanel");
	
	
	// Constructor
			public CreatePendingTrainPage (WebDriver driver) {

		    this.driver = driver;
		    }

	//Method
		
	
			public void clickRemoveCarsfromClipboard() { 
				
				driver.findElement(RemovecarsfromClipboardCheckbox).click();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				
			}
			
			
			public void clickPendingTrainDropDown() { 
				
				driver.findElement(PendingTraindropdownbutton).click();
				driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
				try{
			     	 Thread.sleep(5000);
			     	 
			     	Assert.assertTrue(driver.getPageSource().contains("Select Train Master"));
			     	 
			     	System.out.println("Select Train Master Displayed as Expected");
			     }catch(Exception ex){
			     		ex.printStackTrace();
			     	}
				}
				
		 
			
			public void clickSubmitButton() { 
				
				driver.findElement(submitbutton).click();
				driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
				try{
			     	 Thread.sleep(5000);
			     	 
			     	Assert.assertTrue(driver.getPageSource().contains("Pending Train Header"));
			     	 
			     	System.out.println("Pending Train Header Displayed as Expected");
			     }catch(Exception ex){
			     		ex.printStackTrace();
			     	}
			 }
	
			
			public void clicksubmitonPendingTrainHeader() { 
				
				driver.findElement(submitbutton).click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				try{
			     	 Thread.sleep(5000);
			     	 
			     	Assert.assertTrue(driver.getPageSource().contains("Change Transaction?"));
			     	 
			     	System.out.println("Change Transaction Pop-up Displayed as Expected");
			     }catch(Exception ex){
			     		ex.printStackTrace();
			     	}
			 }
				
				
			
			public void clicksubmitonChangeTransaction() { 
				
				driver.findElement(submitbutton).click();
				driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
				try{
			     	 Thread.sleep(5000);
			     	 
			     	Assert.assertTrue(driver.getPageSource().contains("Visual Yard"));
			     	 
			     	String StatusMessage = driver.findElement(statusmessage).getText();
			     	System.out.println(StatusMessage);
			     }catch(Exception ex){
			     		ex.printStackTrace();
			     	}
				
				
				
				
				
			}
				
		 
	
	
	
	
	
	
	
	
	

}
