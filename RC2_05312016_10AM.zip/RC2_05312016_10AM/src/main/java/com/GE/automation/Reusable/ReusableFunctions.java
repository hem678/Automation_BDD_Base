package com.GE.automation.Reusable;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.GE.automation.pages.RC2LoginPage;
import com.GE.automation.pages.RailConnectMenuPage;
import com.GE.automation.pages.SelectEnvPage;
import com.GE.automation.pages.rc2roadmarkpage;

public class ReusableFunctions {
	
	WebDriver driver;
	
	// Constructor
	public ReusableFunctions (WebDriver driver) {

    this.driver = driver;
    }
	
	
	public void verifyRoadMark() throws Exception { 
		
		rc2roadmarkpage rc2rm = new rc2roadmarkpage(driver);
		rc2rm.setRoadmarkid();
		//rc2rm.setRoadmarkid("EQ55"); // Temp Road Name for Change Road Test Case - need to troubleshoot for datadriven 
        rc2rm.submit();
        try{
	     	 Thread.sleep(9000);
	     	 String getcurrentserver = driver.findElement(By.id("MainContent_TopScreen__nlctl6")).getText(); 
	     	Assert.assertTrue(driver.getPageSource().contains(getcurrentserver));
	     	System.out.println("Server Verified as Expected :" + getcurrentserver);
	     	
        }catch(Exception ex){
		ex.printStackTrace();
		}
        System.out.println("Verified RoadMark - Working as Expected");
		
	}
	
	
  public void verifyLogin() throws Exception {
	  
	  RC2LoginPage rc2login=new RC2LoginPage(driver);
		 
		 rc2login.setUsername();
		 rc2login.setPassword();
		 rc2login.clickSubmit();
		 try{
        	 Thread.sleep(5000);
        	}catch(Exception ex){
        		ex.printStackTrace();
        	}
        System.out.println("Verified Login - Working as Expected");
	  }
  
  
  public void gotoEnv() { 
	  
	  SelectEnvPage senv=new SelectEnvPage(driver);
	  
	  senv.selectEnv();
	  try{
     	 Thread.sleep(4000);
     	}catch(Exception ex){
     		ex.printStackTrace();
     	}
     System.out.println("Selected QA Environemnt ");
	  }
	  
	  
	  
   
	public void gotoVisualYard() { 
		
		RailConnectMenuPage  rcmenu=new RailConnectMenuPage(driver);
		
		rcmenu.gotoVisualYardLink();
		try{
	     	 Thread.sleep(7000);
	     	Assert.assertTrue(driver.getPageSource().contains("Visual Yard"));
	     	
		}catch(Exception ex){
	     		ex.printStackTrace();
	     	}
	     System.out.println("Visual Yard Page Launched - Working as expected");
		  }
		
		
	//}
	
	
	public void setIncrementTime() { 
		
		//public static void main(String[] args) {
			 
			 // Create object of SimpleDateFormat class and decide the format
				 SimpleDateFormat dateFormat = new SimpleDateFormat("HHmm");
			 //Calendar calendarAdd = Calendar.getInstance();
			 //calendarAdd.setTime(date1);
			 
			 //get current date time with Date()
			 Date date = new Date();
			 
			 // Now format the date
			 //String date1= dateFormat.format(date);
			 
			 Calendar calendarAdd = Calendar.getInstance();
			 calendarAdd.add(Calendar.MINUTE,15);
			 String date1 = dateFormat.format(calendarAdd.getTime());
			 
			 
			 // Print the Date
			 //System.out.println("Incremented Time  : " +date1);
		
		
	}
	
	
	

}
