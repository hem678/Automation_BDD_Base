package com.GE.automation.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class CreateWorkListPage {

	
	WebDriver driver;
	
	 //Locators / Objects 
	By RemovecarsfromClipboardCheckbox = By.id("keepCarsInParkingLot");
	By worklistIDDropDown = By.id("vyOptionBtnArrows");
	By submitbutton = By.xpath("//a[contains(text(),'Submit')]");
	By statusmessage = By.id("StatusBarPanel");
	By backbutton = By.xpath("//a[contains(text(),'Back')]");
	
	
	// Constructor
			public CreateWorkListPage (WebDriver driver) {

		    this.driver = driver;
		    }

	//Method
	
			public void clickRemoveCarsfromClipboard() { 
				
				driver.findElement(RemovecarsfromClipboardCheckbox).click();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				}
	
	
	
			public void clickWorkListIDDropDown() { 
				
				driver.findElement(worklistIDDropDown).click();
				driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
				try{
			     	 Thread.sleep(5000);
			     	 
			     	Assert.assertTrue(driver.getPageSource().contains("Select Work List Master"));
			     	 
			     	System.out.println("Select Work List Master Displayed as Expected");
			     }catch(Exception ex){
			     		ex.printStackTrace();
			     	}
				}
			
			
			
			public void clicksubmitbuttononCreateWLpopup() { 
				
				driver.findElement(submitbutton).click();
				driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
				try{
			     	 Thread.sleep(5000);
			     	 
			     	Assert.assertTrue(driver.getPageSource().contains("Work List Header"));
			     	 
			     	System.out.println("Work List Header Displayed as Expected");
			     }catch(Exception ex){
			     		ex.printStackTrace();
			     	}
				}
				
			
			public void clicksubmitonWLHeader() { 
				
				driver.findElement(submitbutton).click();
				driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
				try{
			     	 Thread.sleep(5000);
			     	 
			     	Assert.assertTrue(driver.getPageSource().contains("Text"));
			     	 
			     }catch(Exception ex){
			     		ex.printStackTrace();
			     	}
			}
	
	
			public void clickBackButtonon() { 
				
				driver.findElement(backbutton).click();
				driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
				try{
			     	 Thread.sleep(5000);
			     	 
			     	Assert.assertTrue(driver.getPageSource().contains("Visual Yard"));
			     	 
			     	System.out.println("WorkList Instructions Displayed as Expected");
			     	String StatusMessage = driver.findElement(statusmessage).getText();
			     	System.out.println(StatusMessage);
			     }catch(Exception ex){
			     		ex.printStackTrace();
			     	}
				
			} 
	
	
	
	
	
	
	
	
	
	
	
}
