package com.GE.automation.pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.RC2.TestBase.TestBase;

public class VisualYardPage   {
	
	WebDriver driver;
	
	 //Locators / Objects 
	By select1car = By.xpath("html/body/div[3]/div[3]/div[2]/ul/li[1]");
	By select2car = By.xpath("html/body/div[3]/div[3]/div[2]/ul/li[2]");
	By optiondropdown = By.id("carsSelectedMainFunctionID");
	By MoveCarsLink = By.xpath("//a[contains(text(),'Move Cars')]");
	By submitbutton = By.xpath("//a[contains(text(),'Submit')]");
	By statusmessage = By.id("StatusBarPanel");
	By viewsbuttononMainMenu = By.id("MainContent_FunctionKeyPanel__nlctlviews");
	By AddViewsButton = By.xpath("//a[contains(text(),'Add View')]");
	By AddfromSelectedTracksButton = By.xpath("//a[contains(text(),'Add from Selected Tracks')]");
	By AddfromBuildCriteria = By.xpath("//a[contains(text(),'Add from Build Criteria')]");
	By AddfromKeyList = By.xpath("//a[contains(text(),'Add from Key List')]");
	By FindCarInput = By.id("findCarVYid1");
	By gobutton = By.id("vyFindCarGoButton");
	By clipboardmessage = By.id("carSelectionHandle");
	By listviewbuttononMainMenu = By.id("MainContent_FunctionKeyPanel__nlctl4890vylistview");
	
	
	// Constructor
		public VisualYardPage (WebDriver driver) {

	    this.driver = driver;
	    }

		//Method
	
		public void selectcars() throws Exception { 
		
			
			driver.findElement(select1car).click();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.findElement(select2car).click();
			
		}

		public void gotoMoveCarsfromOptions() { 
			
			Select optionsdropdown = new Select(driver.findElement(optiondropdown));
			
			optionsdropdown.selectByVisibleText("Move Cars");
			
			
			
			
//			driver.findElement(optiondropdown).click();
//			driver.findElement(MoveCarsLink).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			Assert.assertTrue(driver.getPageSource().contains("Move Cars"));
			System.out.println("Move Cars Pop-Up Displayed - Working as Expected");
		}
	
	
		
		public void resequencecars() { 
			
			driver.findElement(select1car).click();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			WebElement sourcecar = driver.findElement(select1car);
			WebElement targetcar = driver.findElement(select2car);
			
			(new Actions(driver)).dragAndDrop(sourcecar, targetcar).perform();
			
			try{
		     	 Thread.sleep(5000);
		     	 
		     	Assert.assertTrue(driver.getPageSource().contains("Resequence on Same Track"));
		     	 
		     	System.out.println("Resequence on Same Track Popup Displayed");
		     	driver.findElement(submitbutton).click();
		     	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		     	String StatusMessage = driver.findElement(statusmessage).getText();
		     	
		     	System.out.println("Resequence on Same Track Done Status Message :" +StatusMessage);
		     	
		     	
		     	
			}catch(Exception ex){
		     		ex.printStackTrace();
		     	}
			}
	

		
		
		public void gotoAddViewfromSelectedTracks() { 
			
			driver.findElement(viewsbuttononMainMenu).click();
			driver.findElement(AddViewsButton).click();
			driver.findElement(AddfromSelectedTracksButton).click();
			try{
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		     	Assert.assertTrue(driver.getPageSource().contains("Add New View"));
		     	System.out.println("Add New View Page Displayed");
		     	}catch(Exception ex){
		     		ex.printStackTrace();
		     	}
			}
			
		public void gotoAddViewfromBuildCriteria() { 
			
			driver.findElement(viewsbuttononMainMenu).click();
			driver.findElement(AddViewsButton).click();
			driver.findElement(AddfromBuildCriteria).click();
			try{
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		     	Assert.assertTrue(driver.getPageSource().contains("Add New View"));
		     	System.out.println("Add New View Page Displayed");
		     	}catch(Exception ex){
		     		ex.printStackTrace();
		     	}
			}
			
			
		 public void gotoAddviewfromKeyList() {
			 
			 
			    driver.findElement(viewsbuttononMainMenu).click();
				driver.findElement(AddViewsButton).click();
				driver.findElement(AddfromKeyList).click();
				try{
					Thread.sleep(9000);
			     	Assert.assertTrue(driver.getPageSource().contains("Add Cars"));
			     	System.out.println("Key List/Add Cars Displayed as Expected");
			     	}catch(Exception ex){
			     		ex.printStackTrace();
			     	}
				
			 
		 }
		 
		 public void gotoCreatePendingTrainfromOptions() { 
				
				Select optionsdropdown = new Select(driver.findElement(optiondropdown));
				
				optionsdropdown.selectByVisibleText("Create Pending Train");
				
				
				
				
//				driver.findElement(optiondropdown).click();
//				driver.findElement(MoveCarsLink).click();
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				Assert.assertTrue(driver.getPageSource().contains("Create Pending Train"));
				System.out.println("Create Pending Train Pop-Up Displayed - Working as Expected");
			}
		
		
		 
		 public void gotoCreateWorkList() { 
			 
			 Select optionsdropdown = new Select(driver.findElement(optiondropdown));
				
				optionsdropdown.selectByVisibleText("Create Work List");
				
				
				
				
//				driver.findElement(optiondropdown).click();
//				driver.findElement(MoveCarsLink).click();
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				Assert.assertTrue(driver.getPageSource().contains("Create Work List"));
				System.out.println("Create Work List Pop-Up Displayed - Working as Expected");
			 }
		 
		 
		 public void gotoCreateOutboundConsist() { 
			 
			 	Select optionsdropdown = new Select(driver.findElement(optiondropdown));
			 	
			 	optionsdropdown.selectByVisibleText("Create Outbound Consist");
				
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				Assert.assertTrue(driver.getPageSource().contains("Create Outbound Consist"));
				System.out.println("Create Outbound Consist Pop-Up Displayed - Working as Expected");
			 }
		 
		 
		 public void getcarInitialsandEnterCarinFindCar() { 
			 
			 String car1 = driver.findElement(select1car).getText();
			 
			 String[] arrSplit = car1.split(" ");
				    for (int i=0; i< arrSplit.length; i++)
				    {
				    	String carinitials = (arrSplit[i]);
				      
				    	String carcharacters = carinitials.replaceAll("[^A-Za-z]+", "");
				    	//System.out.println(carcharacters);
				    
				    	driver.findElement(FindCarInput).sendKeys(carcharacters);    
				    }    
			 	}
		 
		 public void clickGOButton() { 
			 
			 driver.findElement(gobutton).click();
			 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			 
			 try{
		     	 Thread.sleep(3000);
		     	 
		     	String StatusMessage = driver.findElement(statusmessage).getText();
		     	System.out.println(StatusMessage + ": Find Cars Working as Expected");
		     	}catch(Exception ex){
		     		ex.printStackTrace();
		     	}
		 	}
		 
		 
		 public void getClipboardStatus() { 
			 
			 String clipboardstatus = driver.findElement(clipboardmessage).getText();
			 System.out.println("Add Cars to Clipboard Working as Expected " +clipboardstatus);
			 
		 }

		 
		 public void clickListView() { 
			 
			 driver.findElement(listviewbuttononMainMenu).click();
			 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
			 try{
		     	 Thread.sleep(3000);
		     	 
		     	Assert.assertTrue(driver.getPageSource().contains("List View Format")); 
		     	 
		     	System.out.println("List View Format Displayed as Expected");
		     	}catch(Exception ex){
		     		ex.printStackTrace();
		     	}
		 	}
		 
		
		 
		 
		 
		 
		 
		 
		 
}
