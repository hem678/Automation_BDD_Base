package com.GE.automation.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class AddCarsKeyListPage {

	WebDriver driver;
	
	 //Locators / Objects 
	By addcars1 = By.id("MainContent_TopScreen__nlgeb1100");
	By addcars2 = By.id("MainContent_TopScreen__nlgeb1108");
	By addcarsnumber1 = By.id("MainContent_TopScreen__nlgeb1101");
	By addcarsnumber2 = By.id("MainContent_TopScreen__nlgeb1109");
	
	By submitbutton = By.xpath("//a[contains(text(),'Submit')]");
	
	
	// Constructor
			public AddCarsKeyListPage (WebDriver driver) {

		    this.driver = driver;
		    }

			//Method
		public void addcars() {
			
			driver.findElement(addcars1).sendKeys("TILX");
			driver.findElement(addcarsnumber1).sendKeys("600882");
			driver.findElement(addcars2).sendKeys("EJE");
			driver.findElement(addcarsnumber2).sendKeys("6296");
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		}
		
		
		public void clicksubmitBtn() {
			
			driver.findElement(submitbutton).click();
			try{
		     	 Thread.sleep(9000);
		     	  
		     	Assert.assertTrue(driver.getPageSource().contains("Visual Yard"));
		     	System.out.println("View Created with Add Cars to KeyList - Working as Expected");
		     	
			}catch(Exception ex){
		     		ex.printStackTrace();
		     	}
		}
	
	
	
	
	
	
	
	
	
	
	
}
