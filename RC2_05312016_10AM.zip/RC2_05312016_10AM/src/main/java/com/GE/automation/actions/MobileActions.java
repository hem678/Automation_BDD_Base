package com.GE.automation.actions;

import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;

import org.openqa.selenium.By;
import org.openqa.selenium.ScreenOrientation;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;

import com.GE.automation.exceptions.WaitException;
import com.GE.automation.utilities.Utilities;


public class MobileActions extends WebActions {

	private AndroidDriver<?> androidDriver;

	public MobileActions(WebDriver driver) {
		super(driver);
		this.androidDriver = (AndroidDriver<?>) super.driver;
	}

	public void tap(String syncKey, By locator) throws TimeoutException, WaitException {
		LOGGER.info(Utilities.getCurrentThreadId() + "Performing tap action on locator:" + locator);
		TouchAction action = new TouchAction(androidDriver);
		action.tap(wait.syncElementUsing(syncKey, androidDriver, locator)).perform();
		LOGGER.info(Utilities.getCurrentThreadId() + "Tapped on element with locator:" + locator);
	}

	public void swipeOnScreen(int xstart, int ystart, int xend, int yend, int duration) {
		LOGGER.info(Utilities.getCurrentThreadId() + "Performing swipe on screen from Start X="
				+ xstart + " Start Y=" + ystart + " to End X=" + xend + " End Y" + yend);
		androidDriver.swipe(xstart, ystart, xend, yend, duration);
		LOGGER.info(Utilities.getCurrentThreadId() + "Swiped on screen with coordinates Start X="
				+ xstart + " Start Y=" + ystart + " End X=" + xend + " End Y" + yend);
	}

	public void setOrientationTo(String orientation) {
		LOGGER.info(Utilities.getCurrentThreadId() + "Changing the Orientation of Device");
		if ("Landscape".equals(orientation)) {
			LOGGER.info(Utilities.getCurrentThreadId() + "Changing the Orientation to Landscape");
			androidDriver.rotate(ScreenOrientation.LANDSCAPE);
			LOGGER.info(Utilities.getCurrentThreadId() + "Device in LANDSCAPE Mode");
		} else {
			LOGGER.info(Utilities.getCurrentThreadId() + "Changing the Orientation to Landscape");
			androidDriver.rotate(ScreenOrientation.PORTRAIT);
			LOGGER.info(Utilities.getCurrentThreadId() + "Device in PORTRAIT Mode");
		}
	}

	public void closeApp() {
		LOGGER.info(Utilities.getCurrentThreadId() + "Closing the application");
		androidDriver.closeApp();
		androidDriver.getNetworkConnection();
		LOGGER.info(Utilities.getCurrentThreadId() + "Application Closed...");
	}

	public void hideKeyboard() {
		LOGGER.info(Utilities.getCurrentThreadId() + "Hiding the Keyboard");
		androidDriver.hideKeyboard();
		LOGGER.info(Utilities.getCurrentThreadId() + "Keyboard Hidden...");
	}

	public void showKeyboard() {
		LOGGER.info(Utilities.getCurrentThreadId() + "Displaying the Keyboard");
		androidDriver.getKeyboard();
		LOGGER.info(Utilities.getCurrentThreadId() + "Keyboard Displayed...");
	}

	public void scrollTo(String text) {
		LOGGER.info(Utilities.getCurrentThreadId() + "Scrolling Into View Text:" + text);
		androidDriver.scrollTo(text);
		LOGGER.info(Utilities.getCurrentThreadId() + "Text Scrolled Into View");
	}
}