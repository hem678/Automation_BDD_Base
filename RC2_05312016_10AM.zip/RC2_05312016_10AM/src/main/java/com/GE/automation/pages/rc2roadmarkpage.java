package com.GE.automation.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.GE.automation.utilities.Constant;
import com.GE.automation.utilities.ExcelUtils;
import com.GE.automation.utilities.ReadExcel;

/**
 * Created by hemanthkumar on 3/21/16.
 */
public class rc2roadmarkpage  {

    WebDriver driver;

    
    //Locators / Objects 
    By Roadmark = By.id("roadName");
    By submit = By.id("submitBtnId");

    


    // Constructor
    	public rc2roadmarkpage (WebDriver driver) {

        this.driver = driver;
        }

    //Method
    	public void setRoadmarkid() throws Exception {
    		
    		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.File_TestData,"Sheet1");
    		String sRoadMark = ExcelUtils.getCellData(1, 0);
    		 
			//String sPassword = ExcelUtils.getCellData(1, 2);
    		
    		//System.out.println(sRoadMark);

        driver.findElement(Roadmark).sendKeys(sRoadMark);
        
        
    	}


    	public void submit() {

        driver.findElement(submit).click();
        }



}
