package com.GE.automation.drivers;

import io.appium.java_client.android.AndroidDriver;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.GE.automation.executionagent.ExecutionAgent;
import com.GE.automation.executionagent.MobileAgent;
import com.GE.automation.property.reader.PropertyManager;
import com.GE.automation.utilities.Logg;
import com.GE.automation.utilities.Utilities;


public class MobileDriver {
	private static final Properties FRAMEWORKPROPERTY = PropertyManager
			.loadFrameworkPropertyFile("framework.properties");
	private static final Logger LOGGER = Logg.createLogger();
	private static final String APPIUMSERVER = FRAMEWORKPROPERTY
			.getProperty("appiumServerIP");
	private static final String APPIUMPORT = FRAMEWORKPROPERTY
			.getProperty("appiumServerPort");
	private static final String DEVICETYPE = FRAMEWORKPROPERTY
			.getProperty("deviceType");
	private static final String TESTTYPE = FRAMEWORKPROPERTY
			.getProperty("testprop");

	@SuppressWarnings("rawtypes")
	public WebDriver getDriver(ExecutionAgent executionAgent) {
		System.out.println("------------------Prop---------------------- ="
				+ TESTTYPE);
		WebDriver driver = null;
		MobileAgent mobileAgent = (MobileAgent) executionAgent;
		DesiredCapabilities capabilities = MobileCapabilities
				.setAppiumNativeAppCapability(DEVICETYPE, mobileAgent);
		try {
			LOGGER.info(Utilities.getCurrentThreadId() + "**Mobile Driver**");
			LOGGER.info(Utilities.getCurrentThreadId()
					+ "Instantiating the Appium Driver");
			if ("emulator".equals(DEVICETYPE) || "real".equals(DEVICETYPE)) {
				driver = new AndroidDriver(new URL("http://" + APPIUMSERVER
						+ ":" + APPIUMPORT + "/wd/hub"), capabilities);
			} else {
				String host = "mobilecloudexpress.davita.com";// http://mobilecloudexpress.davita.com/nexperience/
				String url = "http://" + host
						+ "/nexperience/perfectomobile/wd/hub";
				driver = new AndroidDriver(new URL(url), capabilities);
			}
			LOGGER.info(Utilities.getCurrentThreadId()
					+ "Returning the mobile instance of:" + driver);
		} catch (MalformedURLException me) {
			LOGGER.info(
					"MalformedURLException in the getDriver() method of the MobileDriver class",
					me);
		}
		return driver;
	}
}