package com.GE.automation.exceptions;


public class WaitException extends Exception {

	public WaitException(String message, Throwable cause) {
		super(message, cause);
	}
}
