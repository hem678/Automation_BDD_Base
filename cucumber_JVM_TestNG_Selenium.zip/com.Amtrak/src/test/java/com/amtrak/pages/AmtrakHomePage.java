package com.amtrak.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class AmtrakHomePage   {
	//extends BasePage
	WebDriver driver;
	
 
	
	//By loginlink = By.linkText("Log in");
	//By registerlink = By.linkText("Register");
	
	@FindBy(linkText = "Log in")
	private WebElement loginLink;
	
	@FindBy(linkText = "Register")
	private WebElement registerLink;
	 
	
	
	public AmtrakHomePage(WebDriver driver){
		//super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}  
	
//	@FindBy(how=How.LINK_TEXT, using="Log in")
//	public static WebElement login;
//	
//	@FindBy(how=How.LINK_TEXT, using="Register")
//	public static WebElement register;
	
	
	
	
	public void verifyLoginLink() { 
		
		//driver.get("http://www.amtrak.com");
		//WebElement open = driver.findElement(loginlink);
		//open.click();
		loginLink.click();
		
		
		 
		
	}
	
	 
	public void verifyTitle() { 
		
		//registerLink.click();
		String currenttitile = driver.getCurrentUrl();
		System.out.println("CurrentTitile :" + currenttitile);
		 
	}
	
	
	
	

}
