package com.amtrak.utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

//public abstract class BasePage {
//	public static WebDriver driver;
//	public static boolean bResult;
//
//	public  BasePage(WebDriver driver){
//		BasePage.driver = driver;
//		BasePage.bResult = true;
//	}
//
//}


public class DriverFactory { 
	
	 protected static WebDriver driver;


	    public DriverFactory() {
	        initialize();
	    }

	    public void initialize() {
	        if (driver == null)
	            createNewDriverInstance();
	    }

	    private void createNewDriverInstance() {
	        String browser = new PropertyReader().readProperty("browser");
	        if (browser.equals("firefox")) {
	            driver = new FirefoxDriver();
	        } else {
	            System.out.println("can't read browser type");
	        }
	    }

	    public WebDriver getDriver() {
	        return driver;
	    }

	    public void destroyDriver() {
	        driver.quit();
	        driver = null;
	    }
	
	//protected static WebDriver driver = new FirefoxDriver();
//	protected WebDriver driver;
//	
//	public BasePage(WebDriver driver) {
//	    this.driver = driver;
	 
	
	
 
	
} 